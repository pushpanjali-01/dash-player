import Hls from 'hls.js'
import shaka from "shaka-player";
import dashjs from "dashjs";
import { useState } from 'react';
export function DashPlayer(errorHandling) {
    errorHandling("")
    const video = document.getElementById("videoPlayer");
    let Src = "https://dash.akamaized.net/envivio/EnvivioDash3/manifest.mpd";
    const player = dashjs.MediaPlayer().create();
    player.initialize(video, Src, true);
    player.on(dashjs.MediaPlayer.events.ERROR, function (e) {
        if (!e.event) {
            console.log("(Player)", e.error.code)
            switch (e.error.code) {

                case dashjs.MediaPlayer.errors.DOWNLOAD_ERROR_ID_MANIFEST_CODE:
                    console.log("(Player)DOWNLOAD_ERROR_ID_MANIFEST_CODE(25)")
                    errorHandling("DOWNLOAD_ERROR_ID_MANIFEST_CODE(dash player)")
                    break;

                case dashjs.MediaPlayer.errors.DOWNLOAD_ERROR_ID_CONTENT_CODE:
                    console.log("(Player)DOWNLOAD_ERROR_ID_CONTENT_CODE(dash player)")
                    errorHandling("(Player)DOWNLOAD_ERROR_ID_CONTENT_CODE(dash player)")
                    break;
                default:
                    errorHandling("")
                    break;
            }
            console.log("p", e.error)
        }
    });

}
export function DashPlayerWitWideVinehDrm(errorHandling) {

    errorHandling("")
    const video = document.getElementById("videoPlayer");
    let Src = "https://media.axprod.net/TestVectors/v7-MultiDRM-SingleKey/Manifest_1080p.mpd";
    var protDatas = {
      "com.widevine.alpha": {
        serverURL: "https://drm-widevine-licensing.axtest.net/AcquireLicense",
        httpRequestHeaders: {
            "X-AxDRM-Message": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2ZXJzaW9uIjoxLCJjb21fa2V5X2lkIjoiYjMzNjRlYjUtNTFmNi00YWUzLThjOTgtMzNjZWQ1ZTMxYzc4IiwibWVzc2FnZSI6eyJ0eXBlIjoiZW50aXRsZW1lbnRfbWVzc2FnZSIsImZpcnN0X3BsYXlfZXhwaXJhdGlvbiI6NjAsInBsYXlyZWFkeSI6eyJyZWFsX3RpbWVfZXhwaXJhdGlvbiI6dHJ1ZX0sImtleXMiOlt7ImlkIjoiOWViNDA1MGQtZTQ0Yi00ODAyLTkzMmUtMjdkNzUwODNlMjY2IiwiZW5jcnlwdGVkX2tleSI6ImxLM09qSExZVzI0Y3Iya3RSNzRmbnc9PSJ9XX19.FAbIiPxX8BHi9RwfzD7Yn-wugU19ghrkBFKsaCPrZmU"
        }
    }
    };
    const player = dashjs.MediaPlayer().create();
    player.initialize(video, Src, true);
    console.log("PPPP",player.setProtectionData())
    player.setProtectionData(protDatas)
    

    console.log("drm",protDatas)

    player.on(dashjs.MediaPlayer.events.ERROR, function (e) {

        if (!e.event) {
            console.log("(Player)", e.error.code)
            switch (e.error.code) {

                case dashjs.MediaPlayer.errors.DOWNLOAD_ERROR_ID_MANIFEST_CODE:
                    console.log("(Player)DOWNLOAD_ERROR_ID_MANIFEST_CODE(dash with drm)")
                    errorHandling("(Player)DOWNLOAD_ERROR_ID_MANIFEST_CODE(25)")
                    break;

                case dashjs.MediaPlayer.errors.DOWNLOAD_ERROR_ID_CONTENT_CODE:
                    console.log("(Player)DOWNLOAD_ERROR_ID_CONTENT_CODE(dash with drm)")
                    errorHandling("(Player)DOWNLOAD_ERROR_ID_CONTENT_CODE(dash with drm)")
                    break;
                default:
                    errorHandling("")
                    break;

            }
            console.log("p", e.error)
        }
    });
}
export function DashPlayerWitPlayReadyhDrm(errorHandling) {

  errorHandling("")
  const video = document.getElementById("videoPlayer");
   let Src = "https://media.axprod.net/TestVectors/v7-MultiDRM-MultiKey-MultiPeriod/Manifest.mpd";
  var protDatas = {
    "com.microsoft.playready": {
      serverURL: "https://drm-playready-licensing.axtest.net/AcquireLicense",
      httpRequestHeaders: {
        "X-AxDRM-Message": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2ZXJzaW9uIjoxLCJjb21fa2V5X2lkIjoiYjMzNjRlYjUtNTFmNi00YWUzLThjOTgtMzNjZWQ1ZTMxYzc4IiwibWVzc2FnZSI6eyJ0eXBlIjoiZW50aXRsZW1lbnRfbWVzc2FnZSIsImtleXMiOlt7ImlkIjoiMDg3Mjc4NmUtZjllNy00NjVmLWEzYTItNGU1YjBlZjhmYTQ1IiwiZW5jcnlwdGVkX2tleSI6IlB3NitlRVlOY3ZqWWJmc2gzWDNmbWc9PSJ9LHsiaWQiOiJjMTRmMDcwOS1mMmI5LTQ0MjctOTE2Yi02MWI1MjU4NjUwNmEiLCJlbmNyeXB0ZWRfa2V5IjoiLzErZk5paDM4bXFSdjR5Y1l6bnQvdz09In0seyJpZCI6IjhiMDI5ZTUxLWQ1NmEtNDRiZC05MTBmLWQ0YjVmZDkwZmJhMiIsImVuY3J5cHRlZF9rZXkiOiJrcTBKdVpFanBGTjhzYVRtdDU2ME9nPT0ifSx7ImlkIjoiMmQ2ZTkzODctNjBjYS00MTQ1LWFlYzItYzQwODM3YjRiMDI2IiwiZW5jcnlwdGVkX2tleSI6IlRjUlFlQld4RW9IT0tIcmFkNFNlVlE9PSJ9LHsiaWQiOiJkZTAyZjA3Zi1hMDk4LTRlZTAtYjU1Ni05MDdjMGQxN2ZiYmMiLCJlbmNyeXB0ZWRfa2V5IjoicG9lbmNTN0dnbWVHRmVvSjZQRUFUUT09In0seyJpZCI6IjkxNGU2OWY0LTBhYjMtNDUzNC05ZTlmLTk4NTM2MTVlMjZmNiIsImVuY3J5cHRlZF9rZXkiOiJlaUkvTXNsbHJRNHdDbFJUL0xObUNBPT0ifSx7ImlkIjoiZGE0NDQ1YzItZGI1ZS00OGVmLWIwOTYtM2VmMzQ3YjE2YzdmIiwiZW5jcnlwdGVkX2tleSI6IjJ3K3pkdnFycERWM3hSMGJKeTR1Z3c9PSJ9LHsiaWQiOiIyOWYwNWU4Zi1hMWFlLTQ2ZTQtODBlOS0yMmRjZDQ0Y2Q3YTEiLCJlbmNyeXB0ZWRfa2V5IjoiL3hsU0hweHdxdTNnby9nbHBtU2dhUT09In0seyJpZCI6IjY5ZmU3MDc3LWRhZGQtNGI1NS05NmNkLWMzZWRiMzk5MTg1MyIsImVuY3J5cHRlZF9rZXkiOiJ6dTZpdXpOMnBzaTBaU3hRaUFUa1JRPT0ifV19fQ.BXr93Et1krYMVs-CUnf7F3ywJWFRtxYdkR7Qn4w3-to"
      }
      // priority:1,
    }
  };
  const player = dashjs.MediaPlayer().create();
  player.initialize(video, Src, true);
  console.log("PPPP",player.setProtectionData())
  player.setProtectionData(protDatas)
  

  console.log("drm",protDatas)

  player.on(dashjs.MediaPlayer.events.ERROR, function (e) {

      if (!e.event) {
          console.log("(Player)", e.error.code)
          switch (e.error.code) {

              case dashjs.MediaPlayer.errors.DOWNLOAD_ERROR_ID_MANIFEST_CODE:
                  console.log("(Player)DOWNLOAD_ERROR_ID_MANIFEST_CODE(dash with drm)")
                  errorHandling("(Player)DOWNLOAD_ERROR_ID_MANIFEST_CODE(25)")
                  break;

              case dashjs.MediaPlayer.errors.DOWNLOAD_ERROR_ID_CONTENT_CODE:
                  console.log("(Player)DOWNLOAD_ERROR_ID_CONTENT_CODE(dash with drm)")
                  errorHandling("(Player)DOWNLOAD_ERROR_ID_CONTENT_CODE(dash with drm)")
                  break;
              default:
                  errorHandling("")
                  break;

          }
          console.log("p", e.error)
      }
  });
}
export function ShakaPlayer() {
    const video = document.getElementById("videoPlayer");
    let Src = "https://dash.akamaized.net/envivio/EnvivioDash3/manifest.mpd";
    shaka.polyfill.installAll();
    let player = new shaka.Player(video);
    player.load(Src)
        .then(() => console.log("Video Load successful"))
        .catch((error) =>
            console.error("Error code", error.code, "object", error)
        );
        console.log("pp",player.shaka.extern.DrmConfiguration())
        player.shaka.extern.DrmConfiguration()
        
        shaka.util.Error.Category = {
            /** Errors from the network stack. */
            'NETWORK': 1,
            /** Errors parsing text streams. */
            'TEXT': 2,
            /** Errors parsing or processing audio or video streams. */
            'MEDIA': 3,
            /** Errors parsing the Manifest. */
            'MANIFEST': 4,
            /** Errors related to streaming. */
            'STREAMING': 5,
            /** Errors related to DRM. */
            'DRM': 6,
            /** Miscellaneous errors from the player. */
            'PLAYER': 7,
            /** Errors related to cast. */
            'CAST': 8,
            /** Errors in the database storage (offline). */
            'STORAGE': 9,
            /** Errors related to ad insertion. */
            'ADS': 10,
          };
          console.log(shaka.util.Error.Code)
          
}
export function ShakaPlayerWithDrm() {
    const video = document.getElementById("videoPlayer");
    let Src = "https://media.axprod.net/TestVectors/v6.1-MultiDRM/Manifest_1080p.mpd";
    shaka.polyfill.installAll();

    const token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ2ZXJzaW9uIjoxLCJjb21fa2V5X2lkIjoiNjllNTQwODgtZTllMC00NTMwLThjMWEtMWViNmRjZDBkMTRlIiwibWVzc2FnZSI6eyJ0eXBlIjoiZW50aXRsZW1lbnRfbWVzc2FnZSIsImtleXMiOlt7ImlkIjoiNmU1YTFkMjYtMjc1Ny00N2Q3LTgwNDYtZWFhNWQxZDM0YjVhIn1dfX0.yF7PflOPv9qHnu3ZWJNZ12jgkqTabmwXbDWk_47tLNE";
    let player = new shaka.Player(video);
    player.load(Src)
        .then(() => console.log("Video Load successful"))
        .catch((error) =>
            console.error("Error code", error.code, "object", error)
        );
    const protection = {
        drm: {
            servers: {
                'com.widevine.alpha': "https://drm-widevine-licensing.axtest.net/AcquireLicense",
            }
        }
    }
    player.getNetworkingEngine().registerRequestFilter(function (type, request) {
        if (type === shaka.net.NetworkingEngine.RequestType.LICENSE) {
            request.headers['X-AxDRM-Message'] = token;
        }
    });
    player.configure(protection)

}
export function HlsPlayer() {
    const video = document.getElementById("videoPlayer");
    let Src = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8";
    if (Hls.isSupported()) {
        let config = {
            autoStartLoad: true,
            startPosition: -1,
        };
        let hls = new Hls(config);
        hls.attachMedia(video);
        hls.on(Hls.Events.MEDIA_ATTACHED, function () {
            hls.loadSource(Src);
        });
    } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = Src;
    }
    Hls.on(Hls.Events.ERROR, function (event, data) {
        // console.log(Hls.ErrorDetails,'ll')
        if (data.fatal) {
          console.log(data,'data2')
          switch (data.details) {
            
            // case Hls.ErrorTypes.NETWORK_ERROR:
            //   // try to recover network error
            //   console.log('fatal network error encountered, try to recover');
            //   hls.startLoad();
            //   break;
             
              case "fragLoadError":
                console.log('  FRAG_LOAD_ERROR,Identifier for fragment load error');
                Hls.startLoad();
                break;
              case "manifestLoadError":
                console.log(' MANIFEST_LOAD_ERROR,Identifier for a manifest load error');
                Hls.startLoad();
                break;
              case "bufferAppendError":
                console.log(' BUFFER_APPEND_ERROR,Identifier for a buffer append error');
                Hls.startLoad();
                break;
              case "bufferAppendingError":
                console.log('BUFFER_APPENDING_ERROR,Identifier for a buffer appending error');
                Hls.startLoad();
                break;
              case "fragLoadTimeOut":
                console.log('  FRAG_LOAD_TIMEOUT, Identifier for a fragment TimeOut error event');
                Hls.startLoad();
                break;
              case " manifestLoadTimeOut":
                console.log('  MANIFEST_LOAD_TIMEOUT,Identifier for a manifest load timeout');
                Hls.startLoad();
                break;
             
              
            case Hls.ErrorTypes.MEDIA_ERROR:
              console.log('fatal media error encountered, try to recover');
              Hls.recoverMediaError();
              break;
            default:
              // cannot recover
              Hls.destroy();
              break;
          }
        }
      });
    
}
