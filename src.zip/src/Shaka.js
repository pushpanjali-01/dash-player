import react, { useEffect } from "react";
import shaka from "shaka-player";

const Shaka = (open) => {
  useEffect(() => {
    
    initPlayer()
    
  }, [])
//   const shakabutton=()=>{
//     initPlayer()
// }
  const initPlayer = () => {
    // Video Manifest URL
    // onClick={open}
    const manifestUri =
      "https://media.axprod.net/TestVectors/v6.1-MultiDRM/Manifest_1080p.mpd";

    // Install all the required Polyfill
    shaka.polyfill.installAll();
    const video = document.getElementById("video");
    // const ui = video['ui'];
    //ui.configure(config);
    // const controls = ui.getControls();
    // player = controls.getPlayer();
    const token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ2ZXJzaW9uIjoxLCJjb21fa2V5X2lkIjoiNjllNTQwODgtZTllMC00NTMwLThjMWEtMWViNmRjZDBkMTRlIiwibWVzc2FnZSI6eyJ0eXBlIjoiZW50aXRsZW1lbnRfbWVzc2FnZSIsImtleXMiOlt7ImlkIjoiNmU1YTFkMjYtMjc1Ny00N2Q3LTgwNDYtZWFhNWQxZDM0YjVhIn1dfX0.yF7PflOPv9qHnu3ZWJNZ12jgkqTabmwXbDWk_47tLNE";
    let player = new shaka.Player(video);
    player.load(manifestUri)
      .then(() => console.log("Video Load successful"))
      .catch((error) =>
        console.error("Error code", error.code, "object", error)
      );

    const protection = {
      drm: {
        servers: {
          'com.widevine.alpha': "https://drm-widevine-licensing.axtest.net/AcquireLicense",
        }
      }
    }
    player.getNetworkingEngine().registerRequestFilter(function (type, request) {
      if (type === shaka.net.NetworkingEngine.RequestType.LICENSE) {
        request.headers['X-AxDRM-Message'] = token;
      }
    });

    player.configure(protection)
    // player.getConfiguration();
    player.configure({
      streaming: {
        bufferingGoal: 120,
        rebufferingGoal: 30,
        bufferBehind: 30,
        alwaysStreamText: true,
      },
      
      abr: {
        bandwidthDowngradeTarget: 0.95,
        bandwidthUpgradeTarget: 0.85,
        defaultBandwidthEstimate: 500000,
        enabled: true,
        switchInterval: 8,
      },
      playRangeEnd: Infinity,
      playRangeStart: 0,
      preferredAudioLanguage: "fr-CA",
      preferredTextLanguage: "el",
      manifest: {
        retryParameters: {
          timeout: 30000,       // timeout in ms, after which we abort
          stallTimeout: 5000,  // stall timeout in ms, after which we abort
          connectionTimeout: 10000, // connection timeout in ms, after which we abort
          maxAttempts: 2,   // the maximum number of requests before we fail
          baseDelay: 1000,  // the base delay in ms between retries
          backoffFactor: 2, // the multiplicative backoff factor between retries
          fuzzFactor: 0.5,  // the fuzz factor to apply to each retry delay
        }
      },
      drm: {
        retryParameters: {
          backoffFactor: 2,
          baseDelay: 1000,
          fuzzFactor: 0.5,
          maxAttempts: 2,
          timeout: 0
        }
      },
      // UIConfiguration: {
      //   singleClickForPlayAndPause: false,
      //   addBigPlayButton:true,
      //   enableKeyboardPlaybackControls:false
      //  // seekBarColors :{base: string, buffered: string, played: string, adBreaks: string}
      // },
      // ManifestConfiguration :{
      //   disableText: false,
      //   disableAudio:true,
      // },

    });
    player.configure({


    })

  }
  return (
    <div className="App">
        {/* <button onClick={initPlayer()}>shaka</button> */}
      <video id="video" controls
        onPlaying={() => console.log('(Player)playing')}
        onPause={() => console.log('(Player)pause')}
        onSeeking={() => console.log('(Player)seeking')}
        onWaiting={() => console.log('(Player)waiting')}
        onVolumeChange={() => console.log('(Player)volumeChnage')}
        onLoadStart={() => console.log('(Player)Loadstart')}
        onError={() => console.log('(Player)error')}
        onStalled={() => console.log('(Player)stalled')}
      ></video>
    </div>
  );
}
export default Shaka;

