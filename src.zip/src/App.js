import React, { useEffect, useState } from "react";
import "./App.css";
import { DashPlayer, HlsPlayer, ShakaPlayer, ShakaPlayerWithDrm, DashPlayerWithDrm } from "./Player";

const App = () => {
  const [btn, setBtn] = useState(null);
  const[error,setError]=useState("");
  useEffect(() => {
    playerClick();
  }, []);

 const errorHandling=(error)=>{
  console.log("ppp",error)
  setError(error)

 }
  const playerClick = (item = 0) => {
    if (btn === item) {
      return
    }
    setBtn(item);
    if (item === 0) {
      DashPlayer(errorHandling)
    } else if (item === 1) {
      DashPlayerWithDrm(errorHandling)
    } else if (item === 2) {
      ShakaPlayer()
    } else if (item === 3) {
      ShakaPlayerWithDrm()
    } else if (item === 4) {
      HlsPlayer()
    }
    else {
      DashPlayer()
    }
  };
  return (
    <div className="App">
      <h1 className="header">Video Players</h1>
      <div className="container">
        <video id="videoPlayer" controls autoPlay />
      </div>
      <div className="button-container">
        <button
          className={`button-item ${btn === 0 ? "active" : ""}`}
          onClick={() => playerClick(0)}
        >
          Dash Player
        </button>
        <button
          className={`button-item ${btn === 1 ? "active" : ""}`}
          onClick={() => playerClick(1)}
        >
          Dash Player With DRM
        </button>
        <button
          className={`button-item ${btn === 2 ? "active" : ""}`}
          onClick={() => playerClick(2)}
        >
          Shaka Player
        </button>
        <button
          className={`button-item ${btn === 3 ? "active" : ""}`}
          onClick={() => playerClick(3)}
        >
          Shaka Player With DRM
        </button>
        <button
          className={`button-item ${btn === 4 ? "active" : ""}`}
          onClick={() => playerClick(4)}
        >
          Hls Player
        </button>
        {/* {error} */}
      </div>
      {error!=="" && <p>{error}</p>} 
    </div>
  );
}
export default App;